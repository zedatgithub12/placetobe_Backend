<?php return array(
    'root' => array(
        'name' => '__root__',
        'pretty_version' => 'dev-main',
        'version' => 'dev-main',
        'reference' => '194ce4ddda42326a10d512ab9f1279659d0a54cf',
        'type' => 'library',
        'install_path' => __DIR__ . '/../../',
        'aliases' => array(),
        'dev' => true,
    ),
    'versions' => array(
        '__root__' => array(
            'pretty_version' => 'dev-main',
            'version' => 'dev-main',
            'reference' => '194ce4ddda42326a10d512ab9f1279659d0a54cf',
            'type' => 'library',
            'install_path' => __DIR__ . '/../../',
            'aliases' => array(),
            'dev_requirement' => false,
        ),
        'melaku/telebirr' => array(
            'pretty_version' => 'v0.1.0',
            'version' => '0.1.0.0',
            'reference' => '45017042fb3b4727d8d9f7f0246b03c4a8498a28',
            'type' => 'library',
            'install_path' => __DIR__ . '/../melaku/telebirr',
            'aliases' => array(),
            'dev_requirement' => false,
        ),
    ),
);
