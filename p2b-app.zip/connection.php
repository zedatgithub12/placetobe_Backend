<?php
$conn = mysqli_connect('localhost','root','');
$database = mysqli_select_db($conn, 'p2b-app');

?>