<?php
//this file is retrived to server reachablity test made on server mount
$status = "200";

$response[] = array("status"=>$status);
echo json_encode($response);
 ?>
